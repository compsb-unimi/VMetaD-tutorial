This is the force field including the basic multi-eGO parameters
to setup a random coil simulation. 
