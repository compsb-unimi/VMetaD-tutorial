import plumed
import sys
import math

# Check if enough arguments are provided
if len(sys.argv) != 10:
    print("Usage: script.py <fes_file> <min_x_A> <max_x_A> <min_y_A> <max_y_A> <min_x_B> <max_x_B> <min_y_B> <max_y_B>")
    sys.exit(1)

# Load the input parameters
fes_file = sys.argv[1]

min_x_A = float(sys.argv[2])
max_x_A = float(sys.argv[3])
min_y_A = float(sys.argv[4])
max_y_A = float(sys.argv[5])

min_x_B = float(sys.argv[6])
max_x_B = float(sys.argv[7])
min_y_B = float(sys.argv[8])
max_y_B = float(sys.argv[9])

kbt = 2.494339

# Load free-energy profiles
data = plumed.read_as_pandas(fes_file)

# Find minimum value of FES
minf = min(data["ff"])

# Initialize the partition functions for the two basins
F0 = 0.0
F1 = 0.0

# Integrate the probabilities over the defined basins
for j in range(len(data["rho"])):
    x = data["rho"][j]  # Using 'rho' as the X coordinate
    y = data["c"][j]    # Using 'c' as the Y coordinate
    
    # Calculate the probability
    p = math.exp((-data["ff"][j] + minf) / kbt)
    
    # Integrate in the first basin (A)
    if min_x_A <= x <= max_x_A and min_y_A <= y <= max_y_A:
        F0 += p
    
    # Integrate in the second basin (B)
    if min_x_B <= x <= max_x_B and min_y_B <= y <= max_y_B:
        F1 += p

# Calculate the free energy difference
if F0 > 0 and F1 > 0:
    delta_G = -kbt * math.log(F0 / F1)
    print("The free energy difference between basin A and basin B is",round(delta_G/4.184, 2),"kcal/mol")
else:
    print("One of the partition functions is zero. Check the basin limits and try again.")

